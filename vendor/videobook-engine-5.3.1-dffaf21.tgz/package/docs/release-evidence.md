# MVP release evidence

Audit date: September 6, 2026 (Asia/Bangkok). Functional baseline: engine
`e328f5e` (runtime `bf952c5`), consumer `96892e26`. Performance artifacts retain their original
revision and hardware qualifications.
This is an assessment of the requirements in
`docs/mvp-prd.md`, not a release approval. E4, E5 and the MVP remain incomplete.
Beads contains the work assignments and current status; this report records
the evidence and its limits at these revisions.

## Performance and quality

The available machine reports Apple M1 Pro, 10 logical CPUs and 16 GiB RAM.
The PRD specifies M2 Pro, 16 GB RAM and local SSD. Existing measurements retain
their actual hardware qualification; none is an M2 Pro acceptance run.

| Requirement | Evidence inspected | Assessment and follow-up |
| --- | --- | --- |
| VE-NFR-001: 1,000-artifact open and semantic summary <2 s | `benchmarks/results/temporal-100k-fresh-process.json`: 1.14 s on M1 Pro, healthy compacted retained fixture | Supported on measured hardware; current-source reference-device run remains in `ve-ovz.9`. |
| VE-NFR-002: metadata and imported normalized transcript searchable <5 s after semantic commit | Engine lexical query regressions and consumer `tests/v2/semantic-index-job.test.ts` exercise indexed text | No timed end-to-end semantic-commit-to-query evidence for both inputs. `ve-ovz.9`. |
| VE-NFR-003: searchable coverage at least every 60 source seconds, resume last committed batch | Full persisted synthetic benchmark: 4,000 batches, at most 30 source seconds per batch, every persisted cursor checked, first coverage about 40 ms. Consumer `commitDeepBatches` persists cursors. | Synthetic API cadence is proved; actual model/job pipeline cadence and interrupted resume need direct verification. `ve-ovz.9`. |
| VE-NFR-004: 100k moments, warm p50 <500 ms, p95 <1.5 s including hybrid | Safe-cache run: 50 reads per mode, p95 image 72 ms/video 151 ms/hybrid 371 ms; public query call includes ranking | Passes recorded synthetic workload on M1 Pro. Reference hardware/current-source qualification remains in `ve-ovz.9`. |
| VE-NFR-005: 100-operation preview on 1,000 clips, p95 <250 ms, no mutation | `tests/edit-transactions.test.ts` seeds the correct scale but measures one preview and allows 500 ms; other edit tests check deterministic preview | Existing timing assertion is weaker than the requirement. Repeated strict distribution and storage invariants required by `ve-ovz.9`. |
| VE-NFR-006: same commit batch, p95 <1 s | Same test measures one commit under 1 s | One sample cannot establish p95. `ve-ovz.9`. |
| VE-NFR-007: 100k query/index structures <4 GB RSS beyond loaded model | Full persisted run peak 3.58 GiB including fixture construction; safe-cache query/rebuild process 2.27 GiB; no model loaded | Supported for measured synthetic workload. Reference/current-source run remains in `ve-ovz.9`. |
| VE-NFR-008: forced termination at every SQL/outbox/Dolt boundary | Baseline edit tests only threw exceptions and closed normally. Subsequent `tests/semantic-crash.test.ts` covers real SIGKILL at each semantic/outbox/table-staging/Dolt boundary for a multi-table edit and provenance operation, including interrupted recovery and an intervening write. | Kill matrix exposed and corrected duplicate provenance replay. See `docs/semantic-durability.md` for scope and invariants; tracked in `ve-ovz.10`. |
| VE-NFR-009: stable search ordering, identical canonical previews/hashes | Temporal benchmark repeats queries against unchanged generations; temporal/edit regressions assert stable ordering and equivalent previews | Functional evidence present; include exact repeated large edit workload in `ve-ovz.9`. |
| VE-NFR-010: every application frozen-corpus quality threshold | E4 evaluator and small real-model fixtures exist | Full rights-cleared frozen corpus and judged ranges absent. `ve-s84` remains incomplete; synthetic scale data cannot replace it. |
| VE-NFR-011: with required models cached, search/index/edit/history initiates no network | Per-Engine local-media scopes; nine engine regressions and ten installed-app workflow cases. A real cached CLIP queue index/reference/library/temporal-search/edit/history workflow makes zero model or B2 HTTP requests. Missing-media cases also stay offline, including migration frame preparation. | Media hydration policy and these complete built-in workflows are verified in `ve-ovz.19`. Arbitrary callback networking and explicitly consented remote providers are separate boundaries; broader input-scoping/privacy verification remains `ve-ovz.14`. |
| VE-NFR-012: bounded scale degradation, no corruption/unbounded React payloads/full-vector scan each query | Native ANN candidate retrieval, bounded video starts/windows, stable pagination, cache deletion/replacement regressions; 100k benchmark | Search architecture and measured workload supported. End-to-end larger-book/payload evidence remains part of `ve-ovz.9`; malformed-input and recovery cases are separate. |

Detailed benchmark provenance and raw samples are linked from
`docs/temporal-search-performance.md`. Reused fixtures inherit original
indexing metrics; they do not measure a fresh index build. First-query times
include snapshot loading and are not warm-query latency or cold OS-cache tests.

## Security and privacy

| Section 13 requirement | Evidence inspected | Assessment and follow-up |
| --- | --- | --- |
| Opt-in/configurable, pinned, checksum-verified and disableable model downloads | Engine defaults local-only; built-in pinned model inventories carry upstream Git/LFS digests. The verified file resolver checks downloads and cached files before returning bytes or ONNX paths, including external weights. Real transfers, corrupt caches and installed-package rejection are tested. | Checksum hardening and custom commit pinning are integrated in consumer `80ce4f58`. Remote file requests must match the worker repository/revision, and embedding identities isolate revisions. See `docs/model-integrity.md` and `docs/model-revisions.md`. |
| Scoped provider inputs, local built-in provider, injected network declaration and application consent | Explicit download/inference declarations and separate application grants guard temporal and compatibility dispatch. Actual HTTP tests cover rejected and authorized providers, revocation, changed declarations, and per-Engine scope. CLIP/CLAP declare local inference. | Engine and consumer consent integration are verified. Identical registrations preserve overlapping searches; replacement/removal revokes later calls. Complete input-scoping verification remains `ve-ovz.14`. |
| Argument arrays, bounded outputs, timeouts, cancellation and scoped workspaces; no untrusted shell | Shared media-process limits and isolated model pool provide deadlines, process-group cancellation and owned scratch cleanup. Consumer actual queue tests cancel stalled model requests and preserve source bytes/status. | Engine isolation and consumer signal forwarding are implemented and tested. See `docs/media-limits.md` and `docs/model-isolation.md`. |
| Malformed codec, oversized image, decompression bomb and model OOM fail job without book corruption | Tests reject malformed/oversized/high-expansion inputs; an actual heap-exhausted worker leaves a live engine writable and reopenable and permits fresh-worker retry. Consumer cached-model queue tests verify malformed-image failure and corrected retry. | Process isolation, typed job failures and consumer integration are verified. The worker heap cap is not an OS-wide memory limit. |
| Excerpts/explanations treated as user content | `MomentSearch.tsx` interpolates excerpt text and explanation title through React | Local inspection supports escaping on this surface; cross-surface hostile-content tests remain in `ve-ovz.14`. |
| Logs contain IDs/hashes/sizes/phases/codes rather than secrets/full content | Consumer `7cd32e85` routes owned runtime console and persistent diagnostics through fixed events and validated UUIDs, queue IDs, counts, enums and error codes. Tool/job names require trusted registration. Tests cover private returned/thrown errors, real queue/provider failures, book reopening, explicit chat history and a real subprocess with multi-megabyte private output. | `vb-wtu9` is complete: 3,160 default tests, 19 model/queue tests including all 3 real cached-model cases, media rollback E2E, lint/types/knip/builds and isolated clean install pass. Full caller/job error details and explicit chat content remain available; old diagnostic files are not rewritten. Broader offline/privacy invariants remain `ve-ovz.14`. |
| Content hashes are identity, not authorization | Book-scoped engines exist; CAS can retrieve by hash through configured remote storage | Cross-book/API authorization cannot be inferred from hash identity. Complete access-path audit/tests in `ve-ovz.14`. |
| Remote publication/backup explicit, never triggered by local search | Actual application B2 HTTP counters stay empty through cached indexing, reference preparation, search, edits and history. Explicit backup then performs HEAD/PUT/verification. A configured local catalog backup target stays absent through indexing/search/history and is written only by explicit backup. | The tested object-store and catalog publication boundaries are verified. This is not an authorization audit of every transport or remote service. Cross-book/API access and remaining privacy checks stay in `ve-ovz.14`. |

Remote hydration integrity is verified in engine `07f0515` and consumer
`20db91d1` (`ve-ovz.18` / `vb-fuib`). Eight engine HTTP/public-API cases cover
same-size wrong content, partial failures, concurrent valid/corrupt transfers,
state preservation, retry, cached reuse, and a forget during download. SHA-256
verification precedes local publication; a final synchronous tombstone check
and rename prevent an in-flight download from republishing forgotten bytes.
The actual application B2 adapter rejects a corrupt HTTP response and supports
valid retry and cached reads after the fixture server shuts down. Existing local
objects are not rehashed on every read. This evidence does not establish
cross-book authorization or the complete offline workflow.

Engine `bf952c5` adds `withLocalMedia`: asynchronous per-book scopes block implicit
CAS downloads with typed `MEDIA_MISSING`, while concurrent explicit reads and
other books remain independent. Compatibility and temporal search/indexing,
edits and history use the policy automatically. Restores succeed for committed
metadata when unavailable bytes prevent workspace hydration. Consumer `96892e26`
applies the scope to direct and queued semantic indexing (including migration
frames), temporary references, library asset projection, and ingest status/retry.
Auxiliary failures preserve source-media readiness. Nine missing-media app cases
exercise the actual B2 adapter and explicit retrieval retry; the additional
cached-model case covers search, edits, restoration and explicit backup.

This completes `ve-ovz.19` / `vb-ld4o`, not the complete security/privacy audit.
Cold-index preparation in the media picker was fixed separately in consumer
`185ec77c` (`vb-ackl`), with a real 1,200-vector queue/poll/retry and
persisted-index regression.

Consumer `64da847a` completes `vb-j3qy`: completed image-subject edits, Library
copies and Duplicate Asset schedule detached indexing jobs deduplicated by
artifact and source hash. Semantic indexing and frame preparation select stream
records matching the current file mapping, rather than an older stream for the
same path. The Library reports missing current-source CLIP coverage and offers
an explicit repair action; its MCP endpoint returns queued per-book jobs and the
client polls their status. Repair skips covered media, prepares missing video
frames, continues past per-asset failures and preserves source readiness.

Validation includes 3,176 default tests across 371 files, explicit cached-model
repair of zero-vector and stale-stream cases, corrupt-media continuation and
idempotence, and a real Chromium Library repair/poll/Similar-search flow. Lint,
test types, client/server builds, dead-code checks, generated command references
and isolated clean installation pass. The original failing edited image now
ranks itself first with no book errors. A saved-library repair resolved all 74
current-source coverage gaps; the final scan reports zero missing visual
indexes. One empty copied video was recovered from its exact preceding
nonempty artifact revision after SHA-256, dimensions and duration verification
(`vb-v9nq`), then indexed and retrieved successfully. These fixture and local
library results do not replace the frozen-corpus or reference-hardware gates.

## Migration, consumer and packaging

Section 15.4 migration is covered by `tests/migration.test.ts`, the pinned v4
schema fixture and consumer migration tests. Evidence includes valid notebook
graphs/generation choices, properties/prompts/messages, real timed media,
empty and large catalogs, content-hash validation, unchanged source bytes,
identical reruns, cancellation/process interruption and source edits before
publication. Consumer queue tests cover durable status/cancel, archive/switch
recovery and idempotent reindex scheduling. `ve-ovz.5`, `ve-ovz.6` and `vb-6eu9`
are complete. This migration evidence does not prove general edit durability.

Engine `e328f5e` passed 341 default tests (12 opt-in cases skipped), typecheck
and knip. Runtime `bf952c5` also passed build and standalone installed-package
checks for local-media denial, explicit retry, checksum rejection, README usage,
and native image decoding. [Node 22/24 runtime CI](https://github.com/justintanner/videobook-engine/actions/runs/34007728660)
passed. `e328f5e` adds only the configured-catalog publication regression.
Consumer `96892e26` passed 3,171 default tests across 370 files (4 opt-in cases
skipped), 38 final explicit workflow/migration/indexing checks including the real
cached-model workflow, and the separate 19 model/queue cases with all three
cached-model cases enabled. Lint, test types, dead-code checks, client/server
builds and the final isolated worktree clean install passed. The initial full run
caught the migration-frame hydration bypass while it was being fixed; the final
full-source run is green.

The earlier model-revision baseline `3f9b37d` passed 324 tests (12 opt-in tests skipped), typecheck, knip,
build and the 22-group API benchmark smoke. Node 22/24 CI passed tests,
builds and clean-package verification at `5db34ef`, which differs only by a
bounded cleanup retry in a merge test. The first Node 24 run failed removing
that temporary database directory after its assertions passed; no runtime
source or semantic assertion changed in the cleanup correction. The consent package was also installed
locally with explicit cached CLIP/CLAP inference enabled. Eleven provider-access
tests exercise actual HTTP dispatch, denied/changed/revoked consent, identical
registration during an overlapping query, and compatibility modalities.

Earlier consumer `80ce4f58` passed 3,151 tests across 366 files, lint, test types,
dead-code checks and both builds. Its three real-model queue cases, skipped by
default, passed in the explicit 37-test focused run. Those cases include an
existing-image Similar reference and indexed source retrieval with downloads
disabled. Corrupt pinned caches fail both actual indexing and reference jobs
with `MODEL_UNAVAILABLE` while source bytes/status remain unchanged. This
integration exposed a preparation race: missing tokenizer failure could precede
a corrupt config check in the other branch. Engine `162bdcd` awaits both
branches and prioritizes integrity failure; repeated public-provider and
consumer queue tests verify the correction.

Both worktree and exact committed-source (`80ce4f58`) clean installs passed
native Sharp, MCP create/list, client delivery and graceful shutdown without a
sibling engine checkout.

Consumer vendors `videobook-engine-5.3.1-bf952c5.tgz`, SHA-256
`38df1a6e8d33d805dd8dda8b35fc14b999889dc341a6f15a8d2e2acce380616c`.
Consumer commits are local per its repository policy. Local package smoke and
vendored-consumer verification do not prove installation of a published
registry package: `ve-yc7` and `ve-orp` retain that release gate. Registry
authentication is an unresolved external prerequisite, not retested here.

Subsequent checksum hardening adds verified file resolution for all built-in
model paths, complete upstream digest inventories for three pinned snapshots,
cache-staging cleanup and public-provider corruption regressions. Nine explicit
real-model tests pass, including MiniLM external ONNX weights and offline reopen.
The installed package rejects corrupt pinned configuration and runs cached
CLIP/CLAP inference. The consumer now includes this verified resolver and
explicit application-owned provider download consent.

All 12 explicit real-model checks passed at model-revision baseline `3f9b37d`. The custom-revision
suite serves actual cached CLIP/CLAP/MiniLM files under custom repository IDs,
verifies fixed revision URLs and integrity receipts, indexes and queries real
media, reopens offline, rejects reuse under a different revision, and loads
explicit local model directories. Sixteen default contract tests cover missing
or moving revisions, configuration snapshots, repository-name collisions,
worker file scope, separate modality defaults and legacy visual cache safety.

Legacy compatibility custom image models previously shared the built-in CLIP
vector identity without recording their provenance. The compatibility visual
space now uses `compat-visual-v2`, requiring a one-time reindex instead of
reusing ambiguous old vectors. Temporal index identities, including those used
by the media library, are unchanged. Source files remain intact. This migration
and the commit requirement for custom remote models are documented in
`docs/model-revisions.md`; `ve-ovz.15` and consumer `vb-3f45` are complete.

The full quality corpus, reference-device evidence, newly identified NFR and
security gaps, and published-package verification prevent closing E4/E5/MVP.
